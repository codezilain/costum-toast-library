package com.gunja.customtoast;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CustomToast {

    public static void message(Context context, String message){

        Toast toast=  Toast.makeText(context, message, Toast.LENGTH_LONG);
        View toastView = toast.getView();
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(17);
        toastMessage.setPadding(20, 3, 20, 3);
        toastMessage.setTextColor(context.getColor(R.color.toast_white));
        toastView.setBackgroundResource(R.drawable.toast_bg__background);

        toast.setGravity(Gravity.CENTER, 0, -250);
        toast.show();
    }
}
